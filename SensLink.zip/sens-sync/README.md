# SensLink · 跨端灵敏度同步台

一个**单文件、零依赖、零后端**的鼠标灵敏度换算 / 同步网页。以「转一整圈手移动多少厘米」（`cm/360`）为唯一锚点，把一套设置对齐到多款 FPS 网游，并用一条链接在**电脑端和手机端**之间共享配置。

默认基准就是：`无畏契约（端瓦） 1600 DPI × 0.3` → `eDPI 480`、**`27.21 cm/360`**、`10.71 in/360`。

---

## 为什么做这个

最近在瓦圈和 FPS 圈比较火的一类工具，本质是同一件事：**跨游戏保持肌肉记忆**，代表形态有三种：

| 形态 | 代表开源项目 | 特点 |
|---|---|---|
| 网页换算器 | [GSC / Game-Sensitivity-Converter](https://github.com/TwTsimon/GSC)（90+ 游戏）、各类 Sensitivity Converter | 多游戏、响应式，但通常要后端 / Workers，配置不留痕 |
| 单文件生成器 | 社区常见的 SensForge / `fps-sensitivity-generator.html` | 双击即用，内置瞄准测试，但只覆盖 2-3 款游戏、不带跨端同步 |
| 本地写入器 | [Autosens](https://github.com/sillynov/autosens) | 直接改游戏 cfg 文件，但只有 Windows 桌面端 |

SensLink 取的是三者的交集：**静态网页能覆盖多游戏 + 一条链接在 PC/手机间同步 + 可以直接推到自己的 GitHub 仓库开源**。

> 说明：手机端的角色是「查看、微调、携带并回传配置」。触屏游戏没有 DPI / 鼠标计数概念，因此本工具不做「端游 ↔ 手游触屏灵敏度」换算，只做端游之间的对齐。若你玩的是同一账号下的端游（例如在手机上查参数、回电脑填进游戏），这个链路正好合用。

---

## 快速开始

### 本地直接用
双击 `index.html` 即可，无需安装任何东西，所有计算都在浏览器里完成（二维码也已内嵌，离线可用）。
注意：此时生成的分享链接是 `file://` 路径，只在本机有效；跨设备请复制「分享码」到另一端粘贴，或按下面的步骤部署到 Pages 后直接扫码。

### 部署到 GitHub Pages（推荐，PC / 手机都能扫码打开）

```bash
# 在你自己的 GitHub 上先建一个仓库，例如 senslink
git clone https://github.com/<你的用户名>/senslink.git
cd senslink
cp /path/to/sens-sync/index.html ./index.html
cp /path/to/sens-sync/README.md ./README.md
cp /path/to/sens-sync/LICENSE ./LICENSE
cp /path/to/sens-sync/tests.mjs ./tests.mjs
git add . && git commit -m "feat: SensLink 跨端灵敏度同步台"
git push origin main
```

然后：仓库 **Settings → Pages → Build and deployment → Deploy from a branch → `main` / `root` → Save**。
稍等片刻即可用 `https://<你的用户名>.github.io/senslink/` 访问。把这个地址生成二维码，手机扫码就是同一套配置。

> 也可以放到 Cloudflare Pages / Vercel / Gitee Pages，或任何静态托管；`file://` 下除二维码外全部可用。

### 自测

```bash
node tests.mjs
```

---

## 功能

- **基准配置**：游戏 / DPI / 游戏内灵敏度；实时显示 eDPI、cm/360、in/360、cm/90°。
- **一键换 DPI 不掉手感**：400 / 800 / 1600 DPI 快捷按钮，按 `cm/360` 反算新 sens。
- **目标游戏换算**：源 / 目标可设不同 DPI；给出可直接填写的数值、控制台配置行、以及游戏内小数位四舍五入造成的实际偏差（例如 VAL 只收 3 位小数）。
- **手感微调**：拖动滑杆预览「±30% 更稳 / 更快」，全游戏表联动，满意后一键设为新基准。
- **全游戏等效表**：20 款内置游戏 + 自定义游戏，可搜索、可一键复制成文本。
- **跨端共享**：
  - 分享链接 `?s=SL2.xxxxx`（打开即还原全部设置，含自定义游戏）；紧凑短码约 90 字符，旧版 `SL1.` 链接仍可读取；
  - 分享码（适合微信 / 备忘录粘贴，另一端粘贴即载入）；
  - 本地二维码（浏览器本地绘制，**配置不上传第三方**）；
  - 本机保存多套配置、导出 JSON。
- **添加任意网游**：靶场实测「转满 360° 的鼠标位移」，自动反推该游戏的 `yaw` 并加入换算体系，且会写进分享码，手机端也能还原。

---

## 换算原理

引擎对每个鼠标计数转动的角度叫 **yaw**（°/count）。手真正记住的是物理位移：

```
cm/360   = 914.4 ÷ (DPI × sens × yaw)          # 914.4 = 360 × 2.54
in/360   = 360 ÷ (DPI × sens × yaw)
目标 sens = 源 sens × 源 yaw × 源 DPI ÷ (目标 yaw × 目标 DPI)
```

所以：**同 DPI 下，瓦 → CS2 / Apex 乘 3.1818，瓦 → OW2 / CoD 乘 10.606；CS2 ↔ Apex 直接抄数字，OW2 ↔ CoD 直接抄数字。**

你的默认配置换算结果（DPI 两端都是 1600）：

| 游戏 | 等效灵敏度 |
|---|---|
| 无畏契约（端瓦） | **0.300** |
| CS2 / CS:GO / Apex / 三角洲行动 / KovaaK's | 0.955 |
| 守望先锋 2 / 使命召唤 / 命运 2 | 3.18 |
| Aim Lab（原生档） | 0.42 |
| 漫威争锋 | 1.2 |
| Deadlock | 0.477 |
| 堡垒之夜（百分比滑块） | 3.78% |
| 彩虹六号：围攻 | 3.67 |
| 逃离塔科夫 | 0.17 |

> eDPI 只在**同一款游戏内**可比。CS2 的 eDPI 和瓦的 eDPI 不是一把尺子，不要直接照搬。

### yaw 数据状态

内置 `yaw` 取自公开社区常数，并在界面里标注可信度：

- **已核对**：瓦 0.07；CS2 / CS:GO / Apex / 三角洲 / KovaaK's / ARC Raiders 0.022；OW2 / CoD / 命运 2 0.0066；堡垒之夜 0.005555；R6 0.00572958；漫威争锋 0.0175；Deadlock 0.044；塔科夫 0.125；Aim Lab 0.05。
- **近似**：战地 6、Roblox（受 FOV 或滑块影响）。
- **参考 / 有冲突**：PUBG、Rust、The Finals —— 公开资料给出互相矛盾的系数（The Finals 就有 0.001 与 0.0044 两说，PUBG 有 0.002222 与 0.022 两说）。这类只当起点，**必须进靶场实测一整圈校准**。

主要参考来源：[mouse-sensitivity.com](https://mouse-sensitivity.com)、[SensLab VALORANT 换算页](https://senslab.pro/sensitivity/valorant)、[FPS Aim Trainer 换算说明](https://fpsaim.com/sensitivity-converter.html)、[converter-sensitivity.com](https://converter-sensitivity.com/)、[CSDB 换算表](https://csdb.gg/sensitivity-converter/valorant-to-cs2/)、[eDPI Calculator 18 游戏 yaw 表](https://edpi-calculator.org/sensitivity-converter)。

### 添加一个新游戏（推荐做法）

不猜系数，实测最稳：

1. 游戏内关掉鼠标加速，Windows 指针速度保持 6/11、关闭「提高指针精确度」；
2. 把鼠标贴在尺子起点，匀速横移直到视角**正好转满 360°**，记下位移 `cm`；
3. 在页面第 ⑤ 区填入游戏名、当时的 DPI、当时的 sens 和这个 `cm`；
4. 工具用 `yaw = 914.4 ÷ (DPI × sens × cm)` 反推并加入列表。

之后它和内置游戏完全等价，也会随分享码同步到手机。

---

## 使用边界（很重要）

- 只对齐**腰射 / 基础视角**的 cm/360。**开镜、倍镜倍率、每英雄独立灵敏度、载具灵敏度**都是各游戏里的独立设置，需要另调。
- FOV 不同会让画面「看起来」快慢不同，但手的转动距离是一样的；不要为了观感去手动补偿系数。
- 转换后请在靶场做一次完整 360° 验证：转多了调小、转少了调大，再固定至少一周别频繁改。
- 本页**不读写任何本地文件**，也不会把配置发到服务器（二维码由浏览器本地绘制）。想「一键写进游戏 cfg」可把本页数值配合 [Autosens](https://github.com/sillynov/autosens) 使用。
- 静态网页无法自动读取你鼠标驱动的 DPI，请如实填写鼠标软件里的档位。

---

## 目录

```
index.html    主程序（单文件，HTML + CSS + JS 全内嵌）
tests.mjs     换算公式与游戏表的 Node 自测
README.md     本文件
LICENSE       MIT
```

改游戏表：直接编辑 `index.html` 里的 `GAMES` 数组，每项 `{id, name, yaw, dec, unit, lv, note}` 即可；`lv` 取 `verified | estimate | disputed`，界面会显示对应标签。

二维码生成使用内嵌打包的 [qrcode.js](https://github.com/soldair/node-qrcode) v1.5.4（MIT，Ryan Day），已直接写进 `index.html`，**不依赖任何 CDN**，离线或内网环境也能扫码。

## License

MIT —— 随便改、随便开源、随便部署。
