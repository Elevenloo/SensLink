# SensLink · 个人灵敏度实验室

一个**单文件、零依赖、零后端**的浏览器工具。

> **主次关系：主力是「测出你个人的最佳灵敏度」，跨游戏换算只是把测出来的结果铺开。**
> 默认基准配置：`无畏契约（端瓦） 1600 DPI × 0.3` → `eDPI 480`、`27.21 cm/360`、`10.71 in/360`。

---

## 为什么这样测

最近「调灵敏度」火起来的工具分三类，前两类都有一个共同问题：**问的是感觉，量不到东西**。

| 做法 | 代表 | 问题 |
|---|---|---|
| 主观对比 / PSA 二分法 | [PSA Method](https://www.psamethod.cn/)、[PerfectTenzivity](https://github.com/varunrmantri23/PerfectTenzivity) | 「哪个更舒服」极易被 acclimation 污染——任何值用两天都会觉得舒服；固定 7 轮迭代也不够精细 |
| 只看命中率 | 各类 aim trainer | 分数受反应、时机、压枪影响，灵敏度只是其中一项 |
| **量首次甩枪落点 + 自适应收敛 + 盲测** | [AimFinder](https://aimfinder.pro/methodology)、[XBitLabs Sensitivity Finder](https://www.xbitlabs.com/sensitivity-finder)、[VALORANT 灵敏度选择器](https://chiyuuc.github.io/valorant-sens-finder/)、社区单文件生成器 | 目前最经得起推敲的路子 |

SensLink 走第三条，并且把「测出来之后怎么用」补齐：结果一键流到 20 款游戏的等效表，再用一条短码在电脑和手机之间同步。

### 四步方法

1. **相机 1:1 复刻**：pointer lock 原始输入（`unadjustedMovement`），每收到一个鼠标计数转 `0.07° × sens`，水平 FOV 103°（16:9）。你在这里甩 180° 的手部位移和在端瓦里一样。
2. **度量：首次弹道子运动偏差（first-submovement bias）**。快速瞄准 = 一次不靠视觉反馈的弹道挥动 + 之后的小修正。工具把每次甩枪轨迹切出第一段，拿终点和靶子实际角度比，得到有符号偏差：**正 = 冲过头（灵敏度偏高）**，**负 = 没到（偏低）**。单发很噪，一个 block 的中位数才是信号。
3. **搜索：自适应阶梯（adaptive staircase）**。每轮按偏差方向把 `cm/360` 往减小偏差的方向推，步长随方向反转逐轮收缩；连续两次反转且偏差落进噪声带，或达到 10 轮，判收敛。用 cm/360 而不是灵敏度数值做步长，是因为前者有物理意义、跨游戏通用。
4. **验证：盲测 A/B**。收敛后，推荐值与一个 ±12% 的诱饵随机排成 A、B 各打 6 靶，界面不显示数值，用「偏差绝对值中位数 + 命中数」判定。**推荐值没赢就如实报「无显著差异，保持原值」**，不粉饰算法。

另外提供两个**不参与收敛**的交叉验证场景（追踪压靶 15s / 微修正 20s），用来暴露「只顾甩枪」的偏科：抖动明显通常是偏快，修正拖沓通常是偏慢。

---

## 快速开始

### 本地
双击 `index.html`，无需安装。所有计算、画布、二维码都在浏览器本地完成（二维码库已内嵌，断网可用）。

> 本地打开时分享链接是 `file://` 路径，只在本机有效；跨设备请复制「分享码」到另一端粘贴，或按下面部署到 Pages 后扫码。

### 部署到 GitHub Pages

```bash
git clone https://github.com/<你的用户名>/<仓库名>.git
cd <仓库名>
cp /path/to/sens-sync/{index.html,README.md,LICENSE,tests.mjs} .
git add . && git commit -m "feat: SensLink 个人灵敏度实验室" && git push origin main
```

仓库 **Settings → Pages → Deploy from a branch → `main` / `root` → Save**，稍等即可用 `https://<用户名>.github.io/<仓库名>/` 访问。Cloudflare Pages / Vercel / Gitee Pages 同样可用。

### 自测

```bash
node tests.mjs     # 44 项：换算公式、yaw 表、短码、靶场算法、页面结构
```

---

## 完整使用流程

### 0. 先把测量环境弄干净（很关键）

- Windows 指针速度 **6/11**，关闭「提高指针精确度」；
- 鼠标驱动里关掉一切加速 / 平滑；浏览器缩放 **Ctrl+0** 回 100%；
- 用你平时打游戏的那只鼠标和那块鼠标垫，握法别临时改；
- 页面 HUD 会显示是否拿到原始输入。若显示 ⚠，点「校准鼠标计数 / DPI」：沿尺子单向平移 10 cm，工具算出每厘米上报计数并给出补偿系数。

### 1. 主测试（约 8–10 分钟）

在 ① 区填好 DPI、起始 `cm/360`（默认取你当前配置）、搜索范围、每轮甩枪数，点「进入靶场 · 开始测试」。

靶子出现后**一次快速甩过去并点击，不要慢慢修正**——算法量的是第一下弹道挥动。前 3 个靶热身不计分，每轮 8 次有效甩枪；一轮结束会告诉你中位偏差、过头/不足次数，并自动切到下一档 `cm/360`。收敛后进入盲测 A/B。

> 按 ESC 暂停，进度不丢；「清空测试进度」只清当前会话，历史记录保留。

### 2. 看报告（② 区）

给出：推荐 `cm/360`、在你 DPI 下的端瓦灵敏度、eDPI、收敛轮次、过头/不足次数、盲测结论与置信度、收敛曲线、以及每一次甩枪的原始记录（可导出 JSON）。

报告里写死了几条纪律，照做比多测十次更有用：

- 这是**今天、这套桌椅鼠标垫下**最顺手的甩枪值，不是永久最优；
- **同一天测 2~3 次、方向一致**才采信，历史表就是用来看这个的；
- 填进游戏后**至少打 10 局、固定用一周**再评价。任何新灵敏度头一小时都会觉得别扭；
- 一两发命中、零点几 cm/360 的差异是噪声，别追。[XBitLabs](https://www.xbitlabs.com/sensitivity-finder) 和 [SensLab 的方法论](https://senslab.pro/guides/how-to-pick-your-sens) 都强调这点，「固定一个月」往往比再找一个更准的数字提升更大。

### 3. 交叉验证（可选）

点 ① 区的「追踪压靶」或「微修正」。结果写进报告但**不改推荐值**——它们测的是不同维度，用来判断你是不是为了甩枪牺牲了稳定性。

### 4. 一键流到换算（③–⑤ 区，次要功能）

点「把测试结果设为换算基准」，基准卡、目标游戏结果、全游戏等效表全部联动。也可以手动改基准、一键换 400/800/1600 DPI 不掉手感、拖滑杆预览 ±30% 手感。

### 5. 跨端共享（⑥ 区）

配置压进 84 字符短码：`?s=SL2.xxxxx` 链接、分享码、本地二维码三选一。部署到 Pages 后电脑生成、手机扫码还原；手机端**只能查看报告、换算和携带配置，不能实测**（触屏没有 DPI / 原始鼠标计数概念）。本机还能存多套配置、导出 JSON。

---

## 算法细节

三个纯函数挂在 `window.SensLabCore`，方便二次开发，也方便 `tests.mjs` 直接抽出来跑：

```js
// 1) 切出第一次弹道子运动：越过 25% 距离后，遇到明显反向或 >85ms 停顿即视为第一段结束
analyzeFlick(samples /* [{t,d}]，d 已按目标方向归一化 */, targetDeg)
// → { bias:(endpoint-targetDeg)/targetDeg, endpoint, clean, duration }

// 2) 自适应阶梯（变量是 cm/360）
staircaseStep({cm, lo, hi, step:0.18, reversals, lastDir, rounds, noise:0.06, maxRounds:10}, medianBias)
// bias > +0.06 → cm *= (1+step)   （过头，调慢）
// bias < -0.06 → cm *= (1-step)   （不足，调快）
// 方向反转 → step *= 0.62；噪声带内且 reversals>=2 或 rounds>=10 → converged

// 3) 盲测判定
blindVerdict(A, B)  // A/B = {biases:[], hits}
// 主看 |bias| 中位数，命中率次之；gap < 0.02 且命中率差 < 0.25 → tie / 低置信度
```

相机换算：

```
degPerCount = 914.4 / (DPI × cm/360) × calibScale      # 914.4 = 360° × 2.54 cm/inch
视角角变化 = movementX × degPerCount
屏幕 x     = W/2 + tan(rel°)/tan(103°/2) × W/2
```

`calibScale = (DPI / 2.54) / 实测计数每厘米`，用来补偿没拿到原始输入时系统的指针缩放。

### 与同类实现的差异

- 用 **cm/360** 作为搜索变量（而不是游戏内 sens 数值），步长有物理意义；
- 同时记录「第一子运动偏差」和「点击命中」，两者分开——玩家修正后点中了靶，偏差依然如实记录；
- 盲测结论、置信度、以及「没测出差异」都会写进报告并留在历史里；
- 测试结果和换算配置共用同一套短码，测完直接跨端带走。

---

## 换算部分（次要）

锚点是手真正记住的物理量：

```
cm/360    = 914.4 ÷ (DPI × sens × yaw)
目标 sens = 源 sens × 源 yaw × 源 DPI ÷ (目标 yaw × 目标 DPI)
```

你的默认配置（两端都 1600 DPI）：瓦 `0.300` → CS2 / CS:GO / Apex / 三角洲行动 / KovaaK's `0.955`，守望先锋 2 / 使命召唤 / 命运 2 `3.18`，Aim Lab 原生档 `0.42`，漫威争锋 `1.2`，Deadlock `0.477`，堡垒之夜 `3.78%`，R6 `3.67`，塔科夫 `0.17`。

> eDPI 只在**同一款游戏内**可比，不要拿 CS2 的 eDPI 直接当瓦的用。

**yaw 状态分级**（界面会打标签）：

- 已核对：瓦 0.07；CS2 / CS:GO / Apex / 三角洲 / KovaaK's / ARC Raiders 0.022；OW2 / CoD / 命运 2 0.0066；堡垒之夜 0.005555；R6 0.00572958；漫威争锋 0.0175；Deadlock 0.044；塔科夫 0.125；Aim Lab 0.05。
- 近似：战地 6、Roblox。
- **参考 / 公开数值冲突**：PUBG、Rust、The Finals（The Finals 有 0.001 与 0.0044 两说，PUBG 有 0.002222 与 0.022 两说）。只当起点，必须进靶场实测一整圈校准。

**添加一个新游戏**：不猜系数，用 ⑦ 区实测——关掉加速，贴尺子匀速横移直到视角正好转满 360°，把位移填进去，工具用 `yaw = 914.4 ÷ (DPI × sens × cm)` 反推并加入体系，也会随分享码同步。

主要数据与方法来源：[mouse-sensitivity.com](https://mouse-sensitivity.com)、[AimFinder methodology](https://aimfinder.pro/methodology)、[AimFinder setup](https://aimfinder.pro/setup)、[XBitLabs Sensitivity Finder](https://www.xbitlabs.com/sensitivity-finder)、[SensLab 方法论](https://senslab.pro/guides/how-to-pick-your-sens)、[SensLab VAL 换算页](https://senslab.pro/sensitivity/valorant)、[FPS Aim Trainer](https://fpsaim.com/sensitivity-converter.html)、[converter-sensitivity.com](https://converter-sensitivity.com/)、[CSDB](https://csdb.gg/sensitivity-converter/valorant-to-cs2/)、[eDPI Calculator](https://edpi-calculator.org/sensitivity-converter)、[PSA Calculator](https://psacalculator.cc/zh/sensitivity-finder)。

---

## 诚实的边界

- **只测腰射甩枪**。追踪 / 压枪 / 身法 / 开镜倍率 / 每英雄独立灵敏度 / FOV 观感都不在主测试的结论里；两个交叉验证只做提示，不做收敛。
- **浏览器不是游戏客户端**。相机数学一致，但渲染与输入延迟不同，这里的绝对分数只能在本工具内部比较，不能拿去和游戏内统计对照。
- **需要鼠标 + 桌面浏览器**。触控板没有意义；Firefox / Safari 若不给原始输入，务必先做校准。
- **手机端不测**，只查看和携带。
- **静态网页不读写任何本地文件**，不上传配置（二维码由浏览器本地绘制）。想「一键写进游戏 cfg」可把数值配合 [Autosens](https://github.com/sillynov/autosens) 使用。
- 换鼠标、鼠标垫、握法，或状态明显漂移时重测；别在同一个数字上来回微调。

---

## 目录

```
index.html    主程序（HTML + CSS + JS + 内嵌二维码库，全单文件）
tests.mjs     44 项自测（换算 / yaw 表 / 短码 / 靶场算法 / 页面结构）
README.md     本文件
LICENSE       MIT
```

改游戏表：编辑 `index.html` 里的 `GAMES` 数组，每项 `{id, name, yaw, dec, unit, lv, note}`；`lv` 取 `verified | estimate | disputed`。
改测试参数：`analyzeFlick` 的 `gapMs / minFrac`、`AR.st` 的 `noise / step / maxRounds`、盲测诱饵比例都在同一文件里，纯函数集中在「靶场：纯算法」一段。
`window.SensLabCore` 暴露算法、`window.SensLabState` 暴露实时状态，方便二次开发。

二维码生成使用内嵌打包的 [qrcode.js](https://github.com/soldair/node-qrcode) v1.5.4（MIT，Ryan Day），**不依赖任何 CDN**。

## License

MIT —— 随便改、随便开源、随便部署。
