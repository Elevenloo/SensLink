/**
 * SensLink 自测：node tests.mjs
 * 直接从 index.html 里抽取真实代码运行，避免测试和实现「各写一份公式」。
 */
import fs from 'node:fs';
import vm from 'node:vm';

const html = fs.readFileSync(new URL('./index.html', import.meta.url), 'utf8');
let pass = 0, fail = 0;
const ok = (name, cond, extra = '') => {
  if (cond) { pass++; console.log(`  ✓ ${name}${extra ? '  ' + extra : ''}`); }
  else { fail++; console.log(`  ✗ ${name}  ${extra}`); }
};
const near = (a, b, eps = 1e-6) => Math.abs(a - b) <= eps;

/* ---------- 1. 主脚本语法与 DOM id 引用 ---------- */
console.log('\n[1] 页面结构');
const scripts = [...html.matchAll(/<script(?![^>]*\bsrc=)[^>]*>([\s\S]*?)<\/script>/g)].map(m => m[1]);
const main = scripts[scripts.length - 1] || '';
ok('存在内联主脚本（末段）', scripts.length >= 1);
ok('无外部脚本依赖（完全离线可用）', !/<script[^>]*\bsrc=/.test(html));
try { new vm.Script(main); ok('主脚本语法通过', true); }
catch (e) { ok('主脚本语法通过', false, e.message); }

const ids = new Set([...html.matchAll(/\sid="([^"]+)"/g)].map(m => m[1]));
const refs = [...new Set([...main.matchAll(/\$\('([^']+)'\)/g)].map(m => m[1]))];
const missing = refs.filter(id => !ids.has(id));
ok(`所有 $(id) 引用都有对应元素（共 ${refs.length} 个）`, missing.length === 0, missing.join(', '));

/* ---------- 2. 抽出真实公式与游戏表 ---------- */
const coreSrc = html.match(/const cm360[\s\S]*?const fmt\s*=\s*\(v,n=3\)[^\n]*;/)?.[0];
const gamesSrc = html.match(/const GAMES = (\[[\s\S]*?\n\]);/)?.[1];
ok('成功抽取核心公式', !!coreSrc);
ok('成功抽取 GAMES 表', !!gamesSrc);
if (!coreSrc || !gamesSrc) { console.error('抽取失败，终止'); process.exit(1); }

const core = new Function('const CM_CONST = 914.4;\n' + coreSrc + '\nreturn {cm360,in360,sensFor,convert,fix,fmt};')();
const GAMES = new Function('return ' + gamesSrc)();
const { cm360, in360, sensFor, convert, fix } = core;

/* ---------- 3. 基准配置：1600 DPI × 0.3 端瓦 ---------- */
console.log('\n[2] 默认基准 1600 DPI × 0.3 VALORANT');
const D = 1600, S = 0.3, Y = 0.07;
const cm = cm360(D, S, Y);
ok('cm/360 = 27.2143', near(cm, 914.4 / 33.6, 1e-9), cm.toFixed(4));
ok('in/360 = 10.7143', near(in360(D, S, Y), 360 / 33.6, 1e-9), in360(D, S, Y).toFixed(4));
ok('eDPI = 480', near(D * S, 480));
ok('cm/90° = cm/360 ÷ 4', near(cm / 4, 6.8036, 1e-3));

console.log('\n[3] 已知换算');
const cs2 = convert(S, D, Y, D, 0.022);
ok('瓦 → CS2 = 0.954545…', near(cs2, 0.3 * 0.07 / 0.022, 1e-9), cs2.toFixed(6));
ok('CS2 游戏内三位小数 = 0.955', fix(cs2, 3) === 0.955);
ok('瓦 → Apex 同 CS2', near(convert(S, D, Y, D, 0.022), cs2));
ok('瓦 → OW2 = 3.1818…', near(convert(S, D, Y, D, 0.0066), 0.3 * 0.07 / 0.0066, 1e-9));
ok('目标 DPI 减半 → sens 翻倍', near(convert(S, D, Y, 800, 0.022), cs2 * 2, 1e-9));
const known = cm360(800, 0.4, 0.07);
ok('公开案例 瓦 0.4 @800 = 40.82 cm/360', near(known, 40.8214, 1e-3), known.toFixed(4));
ok('公开案例 瓦 0.4 → CS2 1.2727', near(convert(0.4, 800, 0.07, 800, 0.022), 1.272727, 1e-5));
ok('sensFor / cm360 往返自洽', near(sensFor(cm, D, Y), S, 1e-12));

console.log('\n[4] 游戏表数据');
const dup = GAMES.map(g => g.id).filter((x, i, a) => a.indexOf(x) !== i);
ok(`${GAMES.length} 款游戏，id 无重复`, dup.length === 0, dup.join(','));
ok('全部 yaw > 0 且有限', GAMES.every(g => Number.isFinite(g.yaw) && g.yaw > 0));
ok('全部 dec 在 0-6', GAMES.every(g => Number.isInteger(g.dec) && g.dec >= 0 && g.dec <= 6));
ok('状态标记合法', GAMES.every(g => ['verified', 'estimate', 'disputed'].includes(g.lv)));
const report = GAMES.map(g => {
  const raw = sensFor(cm, D, g.yaw), r = fix(raw, g.dec);
  const err = Math.abs(cm360(D, r, g.yaw) - cm) / cm * 100;
  return { name: g.name, r, err };
});
ok('所有等效值 > 0 且有限', report.every(x => Number.isFinite(x.r) && x.r > 0));
ok('小数位取整造成的 cm/360 偏差均 < 5%', report.every(x => x.err < 5),
   '最大 ' + Math.max(...report.map(x => x.err)).toFixed(2) + '%');
console.log('    主要等效值（1600 DPI）：');
for (const id of ['valorant', 'cs2', 'apex', 'ow2', 'aimlab', 'marvel', 'fortnite', 'r6', 'eft']) {
  const g = GAMES.find(x => x.id === id);
  if (g) console.log(`    ${g.name.padEnd(28)} ${String(fix(sensFor(cm, D, g.yaw), g.dec)).padStart(8)}${g.unit || ''}`);
}

/* ---------- 5. 分享码编解码（中文往返） ---------- */
console.log('\n[5] 分享码');
const b64Src = html.match(/function b64e\(str\)[\s\S]*?function b64d\(s\)[\s\S]*?\n}/)?.[0];
ok('成功抽取 b64e / b64d', !!b64Src);
if (b64Src) {
  const { b64e, b64d } = new Function(
    'const TextEncoder=globalThis.TextEncoder,TextDecoder=globalThis.TextDecoder,btoa=globalThis.btoa,atob=globalThis.atob;' +
    b64Src + '\nreturn {b64e,b64d};'
  )();
  const payload = JSON.stringify({ n: '我的端瓦配置', c: [{ name: '穿越火线', yaw: 0.02 }] });
  ok('含中文的分享码编解码往返一致', b64d(b64e(payload)) === payload);
  ok('分享码不含 + / / / =', !/[+/=]/.test(b64e(payload)));
}

/* ---------- 6. 靶场核心算法 ---------- */
console.log('\n[6] 靶场算法（首次子运动 / 自适应阶梯 / 盲测）');
const algoSrc = html.match(/function analyzeFlick[\s\S]*?window\.SensLabCore = \{[\s\S]*?\};/)?.[0];
ok('成功抽取靶场算法', !!algoSrc);
if (algoSrc) {
  const A = new Function('const window={};\n' + algoSrc + '\nreturn window.SensLabCore;')();
  const trace = (total, n = 6, gap = 0) => Array.from({length:n}, (_,i)=>({t:i*16+gap*(i>2?1:0), d:total/n}));
  const over = A.analyzeFlick(trace(36,6), 30);
  const under = A.analyzeFlick(trace(24,6), 30);
  ok('过头轨迹 bias = +0.2', near(over.bias, 0.2, 1e-9), over.bias.toFixed(4));
  ok('不足轨迹 bias = -0.2', near(under.bias, -0.2, 1e-9), under.bias.toFixed(4));
  ok('空样本不崩溃且 bias = 0', A.analyzeFlick([], 30).bias === 0);
  const back = A.analyzeFlick([{t:0,d:10},{t:16,d:10},{t:32,d:10},{t:48,d:-2},{t:64,d:-2}], 30);
  ok('中途反向时只取第一段（不把修正算进去）', near(back.endpoint, 30, 1e-9), back.endpoint.toFixed(2));
  const paused = A.analyzeFlick([{t:0,d:12},{t:16,d:12},{t:200,d:1},{t:216,d:1}], 30);
  ok('长停顿切出第一子运动', near(paused.endpoint, 24, 1e-9) && paused.clean, paused.endpoint.toFixed(2));

  const base = {cm:30,lo:12,hi:70,step:0.18,reversals:0,lastDir:0,rounds:0,noise:0.06,maxRounds:10};
  const up = A.staircaseStep(base, 0.15);
  ok('系统性过头 → 调慢（cm 增大）', up.cm > 30 && up.direction === 1, up.cm.toFixed(2));
  const down = A.staircaseStep(base, -0.15);
  ok('系统性不足 → 调快（cm 减小）', down.cm < 30 && down.direction === -1, down.cm.toFixed(2));
  const rev = A.staircaseStep({...up,lastDir:1}, -0.15);
  ok('方向反转 → 步长收缩 + reversals+1', rev.reversals === 1 && rev.step < up.step, `step ${rev.step.toFixed(3)}`);
  const conv = A.staircaseStep({...base,reversals:2}, 0.02);
  ok('偏差落进噪声带且已两次反转 → 收敛', conv.converged === true);
  const clampHi = A.staircaseStep({...base,cm:69.9}, 0.3);
  ok('搜索区间上界夹紧', clampHi.cm <= 70 && clampHi.hitBoundary);
  const maxed = A.staircaseStep({...base,rounds:9}, 0.15);
  ok('达到最大轮数强制收敛', maxed.converged === true);

  const A1 = {biases:[0.03,-0.02,0.04,0.02,-0.03,0.03], hits:5};
  const B1 = {biases:[0.16,-0.14,0.18,0.12,-0.15,0.13], hits:2};
  const v1 = A.blindVerdict(A1,B1);
  ok('盲测：偏差更小的一档胜出', v1.winner === 'A' && v1.confidence === 'high', JSON.stringify(v1.winner));
  ok('盲测：反过来也判 B', A.blindVerdict(B1,A1).winner === 'B');
  const tie = A.blindVerdict(
    {biases:[0.03,0.04,0.03,0.04,0.03,0.04],hits:5},
    {biases:[0.04,0.03,0.04,0.03,0.04,0.03],hits:5});
  ok('盲测：差异小于噪声 → 打平 / 低置信度', tie.winner === 'tie' && tie.confidence === 'low');
  ok('degPerCount(1600, 27.214) = 0.021°/count', near(A.degPerCount(1600,914.4/(1600*0.3*0.07)), 0.021, 1e-9));
  ok('sensFromCm 与 cm360 往返自洽', near(A.sensFromCm(cm, 1600, 0.07), 0.3, 1e-12));
}

console.log(`\n结果：${pass} 通过 / ${fail} 失败\n`);
process.exit(fail ? 1 : 0);
